﻿namespace _03.DependencyInversion.Interfaces
{
    public interface IRunnable
    {
        void Run();
    }
}
