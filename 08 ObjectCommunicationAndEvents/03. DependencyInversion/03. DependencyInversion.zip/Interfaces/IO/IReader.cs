﻿namespace _03.DependencyInversion.Interfaces.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
