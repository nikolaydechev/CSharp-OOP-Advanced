﻿namespace _03.DependencyInversion.Interfaces.IO
{
    public interface IWriter
    {
        void WriteLine(string message);
    }
}
