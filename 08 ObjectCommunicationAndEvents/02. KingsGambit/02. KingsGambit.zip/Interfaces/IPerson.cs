﻿namespace _02.KingsGambit.Interfaces
{
    public interface IPerson
    {
        string Name { get; }
    }
}
