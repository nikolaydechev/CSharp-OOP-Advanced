﻿using System;

namespace _05.GenericCountMethod
{
    public class Box<T>
    {
        private T item;

        public Box(T item)
        {
            this.Item = item;
        }

        public T Item { get; set; }
        
        public override string ToString()
        {
            return $"{this.item.GetType().FullName}: {this.item}";
        }
    }
}
