﻿using System;
using System.Linq;
using System.Runtime.InteropServices;

namespace _10.Tuple
{
    public class StartUp
    {
        public static void Main()
        {
            var tokens = GetTokens();
            var name = string.Join(" ", tokens.Take(2));
            var address = string.Join(" ", tokens.Skip(2));

            var tuple = new Tuple<string, string>(name, address);
            Print(tuple);

            tokens = GetTokens();
            var tuple1 = new Tuple<string, int>(tokens[0], int.Parse(tokens[1]));
            Print(tuple1);

            tokens = GetTokens();
            var tuple2 = new Tuple<int, double>(int.Parse(tokens[0]), double.Parse(tokens[1]));
            Print(tuple2);
        }

        public static string[] GetTokens()
        {
            return Console.ReadLine().Split(' ');
        }

        public static void Print<T, U>(Tuple<T, U> tuple)
        {
            Console.WriteLine(tuple);
        }
    }
}
