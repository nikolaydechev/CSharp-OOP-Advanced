﻿using System.Collections.Generic;

namespace _07.CustomList
{
    public class Sorter
    {
        public static void Sort<T>(List<T> list)
        {
            list.Sort();
        }
    }
}
