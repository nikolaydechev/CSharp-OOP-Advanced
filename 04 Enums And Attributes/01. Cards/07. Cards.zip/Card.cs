﻿using System;

namespace _01.Cards
{
    public class Card : IComparable<Card>
    {
        public Card(CardRank cardRank, CardSuit cardSuit)
        {
            this.CardRank = cardRank;
            this.CardSuit = cardSuit;
        }

        public CardRank CardRank { get; set; }
        public CardSuit CardSuit { get; set; }

        public int CardPower()
        {
            return (int)this.CardRank + (int)this.CardSuit;
        }

        public override string ToString()
        {
            return $"Card name: {this.CardRank} of {this.CardSuit}; Card power: {this.CardPower()}";
        }

        public int CompareTo(Card other)
        {
            if (ReferenceEquals(this, other)) return 0;
            if (ReferenceEquals(null, other)) return 1;
            var cardRankComparison = this.CardPower().CompareTo(other.CardPower());
            if (cardRankComparison != 0) return cardRankComparison;
            return CardSuit.CompareTo(other.CardSuit);
        }
    }
}
