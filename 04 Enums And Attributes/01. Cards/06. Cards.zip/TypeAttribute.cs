﻿using System;

namespace _01.Cards
{
    public class TypeAttribute : Attribute
    {
        public TypeAttribute(string type, string category, string description)
        {
           this.Type = type;
           this.Category = category;
           this.Description = description;
        }

        public string Type { get; set; }

        public string Category { get; set; }

        public string Description { get; set; }

        public override string ToString()
        {
            return $"Type = Enumeration, Description = {this.Description}";
        }
    }
}
