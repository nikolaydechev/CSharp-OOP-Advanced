﻿namespace _01.Cards
{
    public class Card
    {
        public Card(CardRank cardRank, CardSuit cardSuit)
        {
            this.CardRank = cardRank;
            this.CardSuit = cardSuit;
        }

        public CardRank CardRank { get; set; }
        public CardSuit CardSuit { get; set; }

        public int CardPower()
        {
            return (int)this.CardRank + (int)this.CardSuit;
        }

        public override string ToString()
        {
            return $"Card name: {this.CardRank} of {this.CardSuit}; Card power: {this.CardPower()}";
        }
    }
}
