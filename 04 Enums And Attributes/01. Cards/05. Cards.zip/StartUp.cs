﻿using System;

namespace _01.Cards
{
    public class StartUp
    {
        public static void Main()
        {
            //EX. 1,2

            //var input = Console.ReadLine();
            //Array cards = Enum.GetValues(typeof(CardRank));
            //Console.WriteLine($"{input}:");
            //foreach (var card in cards)
            //{
            //    Console.WriteLine($"Ordinal value: {(int)card}; Name value: {card}");
            //}

            var cardRank = (CardRank)Enum.Parse(typeof(CardRank), Console.ReadLine());
            var cardSuit = (CardSuit)Enum.Parse(typeof(CardSuit), Console.ReadLine());

            var cardRank1 = (CardRank)Enum.Parse(typeof(CardRank), Console.ReadLine());
            var cardSuit1 = (CardSuit)Enum.Parse(typeof(CardSuit), Console.ReadLine());

            var card = new Card(cardRank, cardSuit);
            var card1 = new Card(cardRank1, cardSuit1);
            Console.WriteLine(card.CompareTo(card1) < 0 ? card1.ToString() : card.ToString());

        }
    }
}
