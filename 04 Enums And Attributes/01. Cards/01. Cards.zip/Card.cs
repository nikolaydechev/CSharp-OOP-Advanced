﻿namespace _01.Cards
{
    public enum Card
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
