﻿using System;

namespace _01.Cards
{
    public class StartUp
    {
        public static void Main()
        {
            var input = Console.ReadLine();

            Array cards = Enum.GetValues(typeof(Card));
            
            Console.WriteLine($"{input}:");

            foreach (var card in cards)
            {
                Console.WriteLine($"Ordinal value: {(int)card}; Name value: {card}");
            }
        }
    }
}
