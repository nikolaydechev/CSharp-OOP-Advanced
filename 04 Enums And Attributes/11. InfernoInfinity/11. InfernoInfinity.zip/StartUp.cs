﻿using _11.InfernoInfinity.Core;

namespace _11.InfernoInfinity
{
    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
