﻿namespace _11.InfernoInfinity.Entities.Gems
{
    public interface IGem
    {
        int Strength { get; }

        int Agility { get; }

        int Vitality { get; }
    }
}
