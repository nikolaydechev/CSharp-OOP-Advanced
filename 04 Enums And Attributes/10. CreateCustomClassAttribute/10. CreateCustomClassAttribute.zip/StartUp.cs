﻿using System;

namespace _10.CreateCustomClassAttribute
{
    [Custom("Pesho", "3", "Used for C# OOP Advanced Course - Enumerations and Attributes.")]
    public class StartUp
    {
        public static void Main()
        {
            var attributes = typeof(StartUp).GetCustomAttributes(false);

            string input;
            while ((input = Console.ReadLine()) != "END")
            {
                //switch (input)
                //{
                //    case "Author":
                //        Console.WriteLine(attributes[0]);
                //        break;

                //    case "Revision":
                //        Console.WriteLine(attributes[1]);
                //        break;

                //    case "Description":
                //        Console.WriteLine(attributes[2]);
                //        break;

                //    case "Reviewers":
                //        Console.WriteLine(string.Join(", ", attributes[3]));
                //        break;
                //}
            }
            Console.WriteLine(attributes[0]);
        }
    }
}
