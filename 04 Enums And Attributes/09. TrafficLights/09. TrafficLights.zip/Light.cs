﻿namespace _09.TrafficLights
{
    public enum Light
    {
        Red = 0,
        Green = 1,
        Yellow = 2
    }
}
