﻿using System;
using System.Collections.Generic;

public class CoffeeMachine
{
    public CoffeeMachine()
    {
        this.InsertedCoins = 0;
        this.CoffeesSold = new List<CoffeeType>();
    }

    public int InsertedCoins { get; private set; }

    public IList<CoffeeType> CoffeesSold { get; private set; }

    public void BuyCoffee(string size, string type)
    {
        switch (size)
        {
            case "Small":
                if (this.InsertedCoins >= (int)CoffeePrice.Small)
                {
                    this.CoffeesSold.Add((CoffeeType)Enum.Parse(typeof(CoffeeType), type));
                    this.InsertedCoins = 0;
                }
                break;

            case "Normal":
                if (this.InsertedCoins >= (int)CoffeePrice.Normal)
                {
                    this.CoffeesSold.Add((CoffeeType)Enum.Parse(typeof(CoffeeType), type));
                    this.InsertedCoins = 0;
                }
                break;

            case "Double":
                if (this.InsertedCoins >= (int)CoffeePrice.Double)
                {
                    this.CoffeesSold.Add((CoffeeType)Enum.Parse(typeof(CoffeeType), type));
                    this.InsertedCoins = 0;
                }
                break;
        }
    }

    public void InsertCoin(string coin)
    {
        var currentCoin = Enum.Parse(typeof(Coin), coin);
        this.InsertedCoins += (int)currentCoin;
    }
}
