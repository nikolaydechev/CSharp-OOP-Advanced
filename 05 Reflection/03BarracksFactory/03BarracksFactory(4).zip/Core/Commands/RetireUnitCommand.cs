﻿namespace _03BarracksFactory.Core.Commands
{
    using Contracts;

    public class RetireUnitCommand : Command
    {
        public RetireUnitCommand(string[] data, IRepository repository, IUnitFactory unitFactory)
            : base(data, repository, unitFactory)
        {
        }

        public override string Execute()
        {
            string unitType = this.Data[1];
            
            return this.Repository.RemoveUnit(unitType);
        }
    }
}
