﻿using System;

public class Program
{
    public static void Main()
    {
        //EX. 1
        //string result = spy.StealFieldInfo("Hacker", "username", "password");
        //EX.2
        //string result = spy.AnalyzeAcessModifiers("Hacker");
        //EX.3
        Spy spy = new Spy();
        string result = spy.RevealPrivateMethods("Hacker");
        Console.WriteLine(result);
    }
}
